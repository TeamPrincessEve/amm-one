'use strict';

var express = require('express');
var multer  = require('multer')();
const sc = require('../server-const');
const db = require('../db');

var router = express.Router();

//router.all('/all', multer.array(), function(req, res, next) {
router.get('/', multer.array(), function(req, res, next) {
    res.set({
        'AMP-Access-Control-Allow-Source-Origin': process.env.CCHOST
    });
    if (!req.query.kw) {
        res.status(sc.codeSuccess);
        res.json({});
    } else if (req.query.kw == "getallfortest") {
        const text = 'SELECT * FROM account';
        db.query(text, (err, ret) => {
            if (err) {
                res.status(sc.codeError);
                res.json({ message: sc.msgError });
                next(err);
                //return next(err);
            } else {
                res.status(sc.codeSuccess);
                res.json({ "items": ret.rows });
            }
        });
    } else {
        var kw = req.query.kw.replace(/%/g, '').trim();
        if (kw) {
            const text = "SELECT * FROM account WHERE name LIKE '%' || $1 || '%' OR description LIKE '%' || $1 || '%'";
            const values = [kw];
            db.query(text, values, (err, ret) => {
                //console.log(ret.rows);
                if (err) {
                    res.status(sc.codeError);
                    res.json({ message: sc.msgError });
                    next(err);
                    //return next(err);
                    //if (process.env.NODE_ENV != "production") console.log(err);
                } else {
                    res.status(sc.codeSuccess);
                    res.json({ "items": ret.rows });
                }
            });
        } else {
            res.status(sc.codeSuccess);
            res.json({});
        }


    }

    
    
});

module.exports = router;