const gulp = require('gulp-help')(require('gulp'));
const postcss = require('gulp-postcss');

const nodemon = require('gulp-nodemon');

gulp.task('default', ['help']);

gulp.task('postcss', 'build postcss files', function() {
  const plugins = [
    require('postcss-import')(),
    require('autoprefixer')(),
    require('postcss-calc')(),
    require('postcss-color-function')(),
    require('postcss-custom-properties')(),
    require('postcss-discard-comments')(),
    require('postcss-custom-media')(),
    //require('cssnano')({zindex: false}),
    //require('postcss-combine-duplicated-selectors')({removeDuplicatedProperties: true}),
  ];
  const replace = require('gulp-replace');
  const options = {};
  return gulp.src(['src/css/cc.css','src/css/page.css'])
      .pipe(postcss(plugins, options))
      .pipe(replace('!important', ''))
      .pipe(gulp.dest('./public/css'))
});

gulp.task('postcss-watch', 'watch and build postcss files', function() {
  gulp.watch(['src/css/cc.css', 'src/css/cc-vars.css', 'src/css/cc-base.css','src/css/page.css', 'src/css/page-vars.css', 'src/css/form.css'], ['postcss']);
});

gulp.task('serve', 'Host a development webserver', ['postcss'], function() {
    nodemon({
        script: 'server.js',
        ext: 'js html',
        env: { 'NODE_ENV': 'development', 'DEBUG': 'express:*', 'CCHOST': 'https://ccamp-hyeri0609.c9users.io:8080' }
        //env: { 'NODE_ENV': 'production', 'CCHOST': 'https://ccamp-hyeri0609.c9users.io:8080' }
    });
});

gulp.task('testcss', 'test build postcss files', function() {
  const plugins = [
    require('postcss-import')(),
    require('autoprefixer')(),
    require('postcss-calc')(),
    require('postcss-color-function')(),
    require('postcss-custom-properties')(),
    require('postcss-discard-comments')(),
    require('postcss-custom-media')(),
    //require('cssnano')({zindex: false}),
    //require('postcss-combine-duplicated-selectors')({removeDuplicatedProperties: true}),
  ];
  const replace = require('gulp-replace');
  const options = {};
  return gulp.src(['src/css/test.css'])
      .pipe(postcss(plugins, options))
      .pipe(replace('!important', ''))
      .pipe(gulp.dest('./public/css'))
});