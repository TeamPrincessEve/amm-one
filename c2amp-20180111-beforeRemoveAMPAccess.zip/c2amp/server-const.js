module.exports = {
    codeError: 422,
    codeSuccess: 200,
    msgError: 'ไม่สามารถทำรายการของคุณได้ กรุณาลองใหม่',
    msgSuccess: 'ดำเนินการเรียบร้อย',
    
};