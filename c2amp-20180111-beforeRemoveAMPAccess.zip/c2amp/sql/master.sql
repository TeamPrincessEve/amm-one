INSERT INTO account_type (name) VALUES ('SEARCH');
INSERT INTO account_type (name) VALUES ('SELF REGISTER');