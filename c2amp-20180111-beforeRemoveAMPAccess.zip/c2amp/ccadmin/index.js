'use strict';

var express = require('express');
var multer  = require('multer')();
const sc = require('../server-const');
const db = require('../db');

var router = express.Router();

var sessiondata = {
  testdata: "Ok, i got it now"
  , isAdmin: true
};



router.get('/', (request, response) => response.render('ccadmin/account-list', sessiondata));
router.get('/account/new', (request, response) => response.render('ccadmin/account-new', sessiondata));
router.get('/account/list', (request, response) => response.render('ccadmin/account-list', sessiondata));
router.get('/account/edit', (request, response) => {
    if (request.query.aid) {
        const text = "SELECT * FROM account WHERE account_id = $1";
        const values = [request.query.aid];
        db.query(text, values, (err, ret) => {
            if (err) {
                response.redirect('/pages/404'); //may need to change to an error page
            }
            if (ret.rows[0]) {
                response.render('ccadmin/account-edit', ret.rows[0]);
            } else {
                //console.log(db.emptyRow(ret));
                response.render('ccadmin/account-edit', db.emptyRow(ret));
            }
        });
    }
});

router.get('/account/s', multer.array(), function(req, res, next) {
    res.set({
        'AMP-Access-Control-Allow-Source-Origin': process.env.CCHOST
    });
    if (!req.query.kw) {
        const text = 'SELECT * FROM account';
        db.query(text, (err, ret) => {
            if (err) {
                res.status(sc.codeError);
                res.json({ message: sc.msgError });
                next(err);
                //return next(err);
            } else {
                res.status(sc.codeSuccess);
                res.json({ "items": ret.rows });
            }
        });
    } else {
        var kw = req.query.kw.replace(/%/g, '').trim();
        if (kw) {
            const text = "SELECT * FROM account WHERE name LIKE '%' || $1 || '%' OR description LIKE '%' || $1 || '%'";
            const values = [kw];
            db.query(text, values, (err, ret) => {
                //console.log(ret.rows);
                if (err) {
                    res.status(sc.codeError);
                    res.json({ message: sc.msgError });
                    next(err);
                    //return next(err);
                    //if (process.env.NODE_ENV != "production") console.log(err);
                } else {
                    res.status(sc.codeSuccess);
                    res.json({ "items": ret.rows });
                }
            });
        }


    }

    
    
});

router.post('/account/c', multer.array(), function(req, res, next) {
    res.set({
        'AMP-Access-Control-Allow-Source-Origin': process.env.CCHOST
    });
    const text = 'INSERT INTO account(user_name,user_password,name,description,birth_date,address,contact_info,weblink,mobile_phone) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *';
    const values = ['', '', req.body.aname, req.body.adesc, null, req.body.aaddress, req.body.acontact, req.body.aweblink, ''];
    db.query(text, values, (err, ret) => {
        if (err) {
            res.status(sc.codeError);
            res.json({ message: sc.msgError });
            next(err);
        } else {
            res.status(sc.codeSuccess);
            res.json({ message: sc.msgSuccess, data: ret.rows[0] });
        }
    })
    
    
});

router.post('/account/u', multer.array(), function(req, res, next) {
    res.set({
        'AMP-Access-Control-Allow-Source-Origin': process.env.CCHOST
    });
    const text = 'UPDATE account SET name = $2, description = $3, address = $4, contact_info = $5, weblink = $6 WHERE account_id = $1 RETURNING *';
    const values = [req.body.aid, req.body.aname, req.body.adesc, req.body.aaddress, req.body.acontact, req.body.aweblink];
    db.query(text, values, (err, ret) => {
        if (err) {
            res.status(sc.codeError);
            res.json({ message: sc.msgError });
            next(err);
        } else {
            res.status(sc.codeSuccess);
            res.json({ message: sc.msgSuccess, data: ret.rows[0] });
        }
    })
    
    
});

router.get('/account/d', multer.array(), function(req, res, next) {
    res.set({
    'AMP-Access-Control-Allow-Source-Origin': process.env.CCHOST
    });
    if (req.query.aid) {
        const text = "DELETE FROM account WHERE account_id = $1";
        const values = [req.query.aid];
        db.query(text, values, (err, ret) => {
            if (err) {
                res.status(sc.codeError);
                res.json({ message: sc.msgError });
                next(err);
            } else {
                res.redirect('/ccadmin/account/list');
            }
        });
    }
    
    
});

module.exports = router;